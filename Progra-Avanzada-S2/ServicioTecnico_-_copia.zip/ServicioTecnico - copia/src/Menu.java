import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.FileReader;

public class Menu {
    public static void main(String[] args) throws IOException {
        GestionClientes gestion = new GestionClientes();
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int resp = 0;
        boolean continuar = true;
        do {
            System.out.println("Director");
            System.out.println("1) inicializar datos");
            System.out.println("2) agregar Cliente");
            System.out.println("3) Eliminar Cliente");
            System.out.println("4) Mostrar Clientes");
            System.out.println("5) agregar Problema");
            System.out.println("Otherwise: Salir");

            resp = Integer.parseInt(reader.readLine());

            switch (resp) {
                case 1:
                	 String csvFile = "data.csv";
                	 FileReader fr = new FileReader(csvFile);
                	 BufferedReader fileReader = new BufferedReader(fr);
                	 String linea;
                	 while ((linea = fileReader.readLine()) != null) {
                		 String [] line = linea.split(",");
                         int rut1 = Integer.parseInt(line[1]);
                         String nombre1 = line[0];
                         String problema1 = line[2];
                         gestion.agregarCliente(rut1, nombre1);
                         gestion.agregarProblema(rut1, problema1);
                     }
                	 fileReader.close();
         			 fr.close();
         			 System.out.println("Inicializado correctamente");
                     break;
                case 2: 
                	System.out.println("Ingrese el RUT del cliente:");
                    int rut = Integer.parseInt(reader.readLine());
                    System.out.println("Ingrese el nombre del cliente:");
                    String nombre = reader.readLine();
                    gestion.agregarCliente(rut,nombre);
                    break;
                case 3:
                    gestion.eliminarCliente();
                    break;
                case 4:
                    gestion.mostrarClientes();
                    break;
                case 5:
                	System.out.println("Ingrese el RUT del cliente:");
                    int rutt = Integer.parseInt(reader.readLine());
                    System.out.println("Ingrese el problema del computador:");
                    String problema = reader.readLine();
                    gestion.agregarProblema(rutt,problema);
                    break;
                default: 
                    System.out.println("Saliendo...\n");
                    continuar = false;
                    break;
            }
        } while (continuar);
    }
}
