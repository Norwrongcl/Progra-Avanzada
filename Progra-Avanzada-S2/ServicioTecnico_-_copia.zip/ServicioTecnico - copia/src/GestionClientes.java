import java.util.HashMap;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;

public class GestionClientes {
    private HashMap<Integer, Cliente> clientes;
    private BufferedReader reader;

    public GestionClientes() {
        this.clientes = new HashMap<>();
        this.reader = new BufferedReader(new InputStreamReader(System.in));
    }

    public void agregarCliente(int rut,String nombre) throws IOException {
        if (clientes.containsKey(rut)) {
            System.out.println("Ya existe un cliente con ese RUT.");
            return;
        }
        Cliente nuevoCliente = new Cliente();
        nuevoCliente.setNombre(nombre);
        nuevoCliente.setRut(rut);

        clientes.put(rut, nuevoCliente);
        System.out.println("Cliente agregado exitosamente.");
    }

    public void eliminarCliente() throws IOException {
        System.out.println("Ingrese el RUT del cliente a eliminar:");
        int rut = Integer.parseInt(reader.readLine());

        if (clientes.containsKey(rut)) {
            clientes.remove(rut);
            System.out.println("Cliente eliminado exitosamente.");
        } else {
            System.out.println("Cliente con el RUT proporcionado no existe.");
        }
    }

    public void mostrarClientes() {
        if (clientes.isEmpty()) {
            System.out.println("No hay clientes registrados.");
            return;
        }

        System.out.println("Listado de Clientes:");
        for (Cliente cliente : clientes.values()) {
            System.out.println("RUT: " + cliente.getRut() + ", Nombre: " + cliente.getNombre());
        }
    }

    public void agregarProblema(int rut,String problema) throws IOException {

        if (!clientes.containsKey(rut)) {
            System.out.println("Cliente con el RUT proporcionado no existe.");
            return;
        }


        Cliente cliente = clientes.get(rut);
        cliente.agregarProblema(problema);

        System.out.println("Problema agregado exitosamente.");
    }
}
